Manual Install Bible-Discovery Plug-In:

Please extract the compressed zip archive to the "database" subfolder of the already installed Bible-Discovery folder.
The program will detect the new plug-in on the next run.
